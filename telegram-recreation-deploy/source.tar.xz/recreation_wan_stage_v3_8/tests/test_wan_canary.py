import pytest
from recreation import wan_canary

def test_canary_budget():
    assert wan_canary.estimated_cost(3.03) == 0.35
    assert wan_canary.estimated_cost(4.01) == 0.40
    assert wan_canary.estimated_cost(5.01) > 0.40


def test_payload_is_one_reference_480p_silent():
    p = wan_canary.payload_for('https://example.org/video.mp4', 352, 624)
    assert p['reference_videos'] == ['https://example.org/video.mp4']
    assert p['aspect_ratio']=='9:16'
    assert p['duration']==3 and p['resolution']=='480p'
    assert p['generate_audio'] is False


def test_canary_fails_closed_without_switch(monkeypatch):
    monkeypatch.setenv('WORKER_MODE', 'canary_once')
    monkeypatch.delenv('WAN_CANARY_ONE_SHOT', raising=False)
    with pytest.raises(RuntimeError, match='explicit one-shot switch'):
        wan_canary.require_approval()


def test_canary_fails_closed_without_max_budget(monkeypatch):
    monkeypatch.setenv('WORKER_MODE','canary_once')
    monkeypatch.setenv('WAN_CANARY_ONE_SHOT','true')
    monkeypatch.setenv('ENABLE_PAID_GENERATION','true')
    monkeypatch.delenv('WAN_CANARY_MAX_USD',raising=False)
    with pytest.raises(RuntimeError, match='budget'):
        wan_canary.require_approval()


def test_canary_does_not_submit_when_already_reserved(monkeypatch):
    monkeypatch.setattr(wan_canary, 'require_approval', lambda: ({'job_id':'j1'}, 'reference0'))
    monkeypatch.setattr(wan_canary.db, 'get_step', lambda *args: {'state':'SUBMITTING'})
    monkeypatch.setattr(wan_canary.provider, 'submit_once', lambda *args: pytest.fail('duplicate provider submission'))
    with pytest.raises(wan_canary.provider.NeedsReview):
        wan_canary.run_once()
