"""Persistent job dispatcher. No in-process long-lived n8n execution."""
import logging
from .voiceover import VoiceConfigurationError
import os
import threading
import time
import uuid
from . import db,storage,telegram,provider,pipeline

logger=logging.getLogger('recreation-worker')
WORKER_ID='worker-'+uuid.uuid4().hex[:8]


def _heartbeat(job_id,stop):
    while not stop.wait(20):
        try: db.heartbeat(job_id,WORKER_ID)
        except Exception: logger.exception('Could not renew lease')


def process_job(job):
    job_id=job['job_id']; stage=job['stage']; chat=job['chat_id']
    if stage=='INGEST':
        key=storage.store_telegram(job_id,job['source_file_id'])
        db.checkpoint(job_id,WORKER_ID,stage='UPLOAD_REFERENCE',state='QUEUED',fields={'original_key':key},
              event=('source_saved','Original video safely backed up to durable media storage'))
        telegram.say(chat,'Original video saved safely. Your source will not need to be uploaded again.')
        return
    return pipeline.process(job)



def loop():
    db.initialize()
    logging.basicConfig(level=logging.INFO)
    last_review=0
    while True:
        try:
            if time.monotonic()-last_review>60:
                db.review_uncertain_submissions()
                last_review=time.monotonic()
            job=db.claim(WORKER_ID)
            if not job:
                time.sleep(3); continue
            stop=threading.Event()
            heartbeat=threading.Thread(target=_heartbeat,args=(job['job_id'],stop),daemon=True)
            heartbeat.start()
            try:
                process_job(job)
            except (provider.NeedsReview,pipeline.ConfigurationError,VoiceConfigurationError) as exc:
                logger.warning('Manual review required at stage %s for job %s: %s',job['stage'],job['job_id'],exc)
                db.checkpoint(job['job_id'],WORKER_ID,state='NEEDS_REVIEW',
                    fields={'last_error':str(exc)[:650]},
                    event=('manual_review',str(exc)[:300]))
                try: telegram.say(job['chat_id'],'Job paused for safe review. Your existing segments and provider request IDs are preserved. Use /status for details.')
                except Exception: logger.exception('Could not notify user')
            except Exception as exc:
                logger.exception('Stage %s failed for %s',job['stage'],job['job_id'])
                attempts=int(job['attempt'])+1
                retry=attempts<=5
                delay=min(900,15*2**(attempts-1))
                db.checkpoint(job['job_id'],WORKER_ID,state='QUEUED' if retry else 'FAILED',
                    delay_seconds=delay if retry else 0,
                    fields={'last_error':str(exc)[:650],'attempt':attempts},
                    event=('retry' if retry else 'failed',str(exc)[:300]))
            finally:
                stop.set(); heartbeat.join(timeout=2)
        except Exception:
            logger.exception('Worker loop exception')
            time.sleep(8)


if __name__=='__main__': loop()
