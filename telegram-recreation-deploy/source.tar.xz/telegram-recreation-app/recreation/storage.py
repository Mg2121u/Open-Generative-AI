"""Durable S3-compatible media storage. All provider-facing links are short-lived presigned URLs."""
import os
import tempfile
import shutil
from pathlib import Path
import boto3
import requests
from .telegram import BOT_API_URL, BOT_TOKEN, telegram


def client():
    return boto3.client('s3',endpoint_url=os.environ.get('S3_ENDPOINT_URL') or None,
        aws_access_key_id=os.environ.get('S3_ACCESS_KEY_ID'),
        aws_secret_access_key=os.environ.get('S3_SECRET_ACCESS_KEY'),
        region_name=os.environ.get('S3_REGION','auto'))


def bucket():
    value=os.environ.get('S3_BUCKET')
    if not value: raise RuntimeError('S3_BUCKET is required to prevent data loss')
    return value


def store_telegram(job_id, file_id):
    info=telegram('getFile',{'file_id':file_id})
    file_path=info.get('file_path')
    if not file_path: raise RuntimeError('Telegram getFile returned no file_path')
    key=f'recreation/{job_id}/original.mp4'
    with tempfile.TemporaryDirectory() as td:
        file=Path(td)/'original.mp4'
        # Local Bot API in --local mode returns absolute paths on shared storage.
        # Otherwise use its HTTP file endpoint (cloud Bot API: <=20MB).
        if Path(file_path).is_absolute():
            if not Path(file_path).is_file():
                raise RuntimeError('Local Bot API returned an absolute path inaccessible to this worker. Share the Bot API download directory with this worker.')
            shutil.copyfile(file_path,file)
        else:
            url=f'{BOT_API_URL}/file/bot{BOT_TOKEN}/{file_path.lstrip("/")}'
            with requests.get(url,stream=True,timeout=(20,90)) as result:
                result.raise_for_status()
                with file.open('wb') as out:
                    for chunk in result.iter_content(1024*1024):
                        if chunk: out.write(chunk)
        if file.stat().st_size<128: raise ValueError('Source download empty')
        client().upload_file(str(file),bucket(),key,
             ExtraArgs={'ContentType':'video/mp4','Metadata':{'job-id':str(job_id)}})
    return key


def presign(key,seconds=7200):
    return client().generate_presigned_url('get_object',Params={'Bucket':bucket(),'Key':key},ExpiresIn=seconds)


def download_key(key,path):
    client().download_file(bucket(),key,str(path))


def upload_key(key,path,mime='video/mp4'):
    client().upload_file(str(path),bucket(),key,ExtraArgs={'ContentType':mime})
    return key


def store_provider_url(url, key, *, max_bytes=250_000_000):
    """Persist a generated provider video before its signed URL expires."""
    from urllib.parse import urlsplit
    if not url.startswith('https://') or not urlsplit(url).hostname:
        raise ValueError('Provider returned invalid non-HTTPS media URL')
    with tempfile.TemporaryDirectory() as td:
        file=Path(td)/'provider.mp4'
        total=0
        with requests.get(url,stream=True,timeout=(20,90)) as response:
            response.raise_for_status()
            with file.open('wb') as out:
                for chunk in response.iter_content(1024*1024):
                    if not chunk: continue
                    total+=len(chunk)
                    if total>max_bytes: raise ValueError('Generated video exceeds storage limit')
                    out.write(chunk)
        if total<128: raise ValueError('Provider output empty')
        upload_key(key,file)
    return key
