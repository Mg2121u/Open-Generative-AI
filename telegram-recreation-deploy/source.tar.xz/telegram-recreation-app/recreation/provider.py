"""Idempotent, durable WaveSpeed generation submission/polling primitives.

This module is reusable by the exact migrated Wan workflow; it deliberately
never invents prompts or changes the reference-generation payload.
"""
import os
import requests
from . import db

WAVESPEED_URL='https://api.wavespeed.ai/api/v3'


class NeedsReview(RuntimeError):
    """Submission may have been accepted and billed; not safe to retry blindly."""


def auth_headers():
    key=os.environ.get('WAVESPEED_API_KEY')
    if not key: raise RuntimeError('WAVESPEED_API_KEY missing')
    return {'Authorization':'Bearer '+key,'Content-Type':'application/json'}


def submit_once(job_id,step_key,endpoint,payload):
    """Submit at most once automatically for a checkpoint key.

    A crash between provider acceptance and writing the provider ID creates an
    ambiguous state; escalate instead of re-running and double billing.
    """
    existing=db.get_step(job_id,step_key)
    if existing:
        if existing['state'] in ('SUBMITTED','POLLING','COMPLETED'):
            return existing
        if existing['state'] in ('SUBMITTING','UNCERTAIN'):
            raise NeedsReview('Provider submission outcome unknown; inspect provider dashboard before retry')
        if existing['state']=='FAILED':
            raise NeedsReview('Manual approval required before recreating a failed paid submission')
    db.prepare_external(job_id,step_key,'wavespeed',{'endpoint':endpoint,'payload':payload})
    try:
        response=requests.post(WAVESPEED_URL+'/'+endpoint.lstrip('/'),
                               headers=auth_headers(),json=payload,timeout=(15,55))
        response.raise_for_status()
        result=response.json()
    except requests.RequestException as exc:
        # Even some 5xx responses can follow accepted provider submissions.
        raise NeedsReview('Submission may have succeeded; check provider jobs before any retry') from exc
    provider_id=(result.get('data') or {}).get('id')
    if not provider_id:
        raise NeedsReview('Provider response lacks a request ID; investigate before retry')
    saved=db.external_submitted(job_id,step_key,provider_id)
    if not saved: raise NeedsReview('Could not save provider request ID; investigate before retry')
    return saved


def poll(step):
    """Read-only polling: safe to retry after timeouts or server restarts."""
    external_id=step['external_request_id']
    if not external_id: raise NeedsReview('No saved provider request ID')
    response=requests.get(WAVESPEED_URL+'/predictions/'+external_id+'/result',
                          headers=auth_headers(),timeout=(15,50))
    response.raise_for_status()
    data=(response.json().get('data') or {})
    status=str(data.get('status','')).lower()
    if status=='completed':
        db.external_finished(step['job_id'],step['step_key'],data)
    elif status in ('failed','cancelled'):
        raise RuntimeError(f'Provider job {external_id} {status}: {str(data.get("error", ""))[:300]}')
    return data


def chat_once(job_id, step_key, body):
    """Synchronous WaveSpeed LLM POST, with write-ahead intent for billing safety.

    A crash after a provider accepted the call is ambiguous; never automatically
    retry such a step, even if no response was durably recorded.
    """
    existing = db.get_step(job_id, step_key)
    if existing:
        if existing['state'] == 'COMPLETED':
            return existing['result']
        raise NeedsReview(f'LLM step {step_key} is {existing["state"]}; manual reconciliation required')
    db.prepare_external(job_id, step_key, 'wavespeed_llm', {'model': body.get('model'), 'body': body})
    try:
        response = requests.post('https://llm.wavespeed.ai/v1/chat/completions',
            headers=auth_headers(), json=body, timeout=(20, 240))
        response.raise_for_status()
        output = response.json()
    except Exception as exc:
        raise NeedsReview(f'LLM {step_key} response uncertain; do not resubmit blindly') from exc
    saved = db.external_finished(job_id, step_key, output)
    if not saved:
        raise NeedsReview('Could not persist LLM result; inspect billing before retry')
    return output


def upload_media_once(job_id, source_path):
    """Original n8n source upload step, checkpointed before the external POST."""
    key='reference_video_upload'
    existing=db.get_step(job_id,key)
    if existing:
        if existing['state']=='COMPLETED':
            value=((existing['result'] or {}).get('data') or {}).get('download_url')
            if not value: raise NeedsReview('Saved source upload lacks a WaveSpeed URL')
            return value
        raise NeedsReview(f'Source upload outcome ambiguous: {existing["state"]}')
    db.prepare_external(job_id,key,'wavespeed',{'endpoint':'media/upload/binary?ext=mp4'})
    try:
        with open(source_path,'rb') as stream:
            result=requests.post(WAVESPEED_URL+'/media/upload/binary?ext=mp4',
                headers={'Authorization':auth_headers()['Authorization'],
                         'Content-Type':'application/octet-stream'},
                data=stream,timeout=(20,300))
            result.raise_for_status()
            payload=result.json()
    except Exception as exc:
        raise NeedsReview('Source upload outcome uncertain; inspect provider before retry') from exc
    url=(payload.get('data') or {}).get('download_url')
    if not url or not url.startswith('https://'):
        raise NeedsReview('Source upload returned no usable WaveSpeed HTTPS download URL')
    db.external_finished(job_id,key,payload)
    return url
