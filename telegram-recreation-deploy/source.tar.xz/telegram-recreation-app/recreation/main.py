import os
from fastapi import FastAPI
from .telegram import router

app=FastAPI(title='Telegram Recreation Studio',docs_url=None,redoc_url=None)
app.include_router(router)

@app.get('/health')
def health():
    required=('DATABASE_URL','S3_BUCKET','S3_ACCESS_KEY_ID','S3_SECRET_ACCESS_KEY',
              'TELEGRAM_BOT_TOKEN','TELEGRAM_WEBHOOK_SECRET')
    return {'service':'telegram-recreation-app','configured':all(os.getenv(v) for v in required),
            'generation_ready':False,'status':'staging_only'}
