# Nicole full-video staging: gated incremental generation

The user confirmed that the 3-second Nicole identity replacement succeeded. This
version extends the exact reference-image + source-video approach over the
**entire archived source** while preserving the original audio. It does not
modify the existing 67-node reference workflow, Nicole production, or n8n.

## Staging plan (no provider charges)

Use `/fullplan` in the separate Recreation Studio Telegram DM. This only reads
an existing local FFmpeg preflight checkpoint and reports segment starts,
durations, how many WaveSpeed generations remain, and an estimate. With the
archived 13.9-second source: five segments (3,3,3,2.9,2 seconds); the first
already-generated, identity-correct 3-second clip is reused. The remaining
four segments have a published-price estimate of **USD $1.10 at 480p**.
WaveSpeed's model bills both the rounded-up reference video and output
seconds, at $0.05 per second. Actual billing may differ.

## Safety

By default, `WORKER_MODE=preflight_only`, `FULL_VIDEO_ONE_SHOT=false`, and
`ENABLE_PAID_GENERATION=false`. Deploying this code makes no paid provider
calls. The dedicated Render worker must also have the existing WaveSpeed key
and a *new*, explicit FULL VIDEO approval containing a maximum estimated USD
cap. The previous $0.40 canary approval is **not** enough.

Activation (ONLY after user approves this exact full-video estimated cap):

- `WORKER_MODE=full_video_once`
- `FULL_VIDEO_ONE_SHOT=true`
- `FULL_VIDEO_APPROVAL_ID=nicole_full_480p_v1_20261115`
- `FULL_VIDEO_MAX_USD=<newly approved cap>`
- `FULL_VIDEO_SOURCE_JOB_ID=<approved archived job UUID>`
- `ENABLE_PAID_GENERATION=true`
- `ENABLE_PAID_VOICE_GENERATION=false`

Every paid segment has a unique, immutable step key with atomic reservation
prior to WaveSpeed POST. Existing completed steps are polled or reused, never
blindly submitted again. A crash between POST and saving the prediction ID
halts for manual billing reconciliation. Completed videos are stored privately
per segment and assembled in source order. Original audio is restored from the
archived MP4, and one private Telegram DM delivery is reserved atomically.
Once complete, restore `WORKER_MODE=preflight_only`, `FULL_VIDEO_ONE_SHOT=false`,
`ENABLE_PAID_GENERATION=false`; do not leave a paid mode running.

## Limitations

Each segment can have a continuity jump at the boundary. The successful first
clip is verified as Nicole identity-guided, but continuity, visual likeness,
and original-audio sync must be checked on the finished video. This is a direct
segment-by-segment 480p recreation; it does not automatically invoke Grok,
Gemini, voice synthesis, or any other paid model.
