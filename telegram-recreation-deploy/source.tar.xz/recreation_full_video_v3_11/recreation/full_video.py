"""Staging-only, restart-safe full-video Nicole recreation.

No billable calls unless an exact cost approval is configured on the *dedicated*
worker. Reuse the already approved and successfully archived first 3-second
Nicole identity segment, generating only subsequent source windows. Each segment
has an immutable provider step key and cannot be paid twice automatically.
The final sound is copied from the original archived video via FFmpeg.
"""
import logging
import math
import os
import tempfile
from pathlib import Path
from urllib.parse import urlsplit, unquote

from botocore.exceptions import ClientError

from . import db, ffmpeg, provider, storage, wan_canary, telegram

LOGGER = logging.getLogger('full-video')
RUN_KEY = 'nicole_full_480p_v1_20261115'
FIRST_CANARY_STEP = wan_canary.STEP_KEY
MAX_SOURCE_SECONDS = 60.0
MAX_CLIPS = 24
CLIP_SECONDS = 3.0
RATE_USD = 0.05
# An approval for the first single-clip canary is NOT an approval for the full video.
MAX_APPROVAL_USD = 10.0


def plan(duration, *, reuse_first=False):
    """Split the *entire* duration, with each reference 2-3.99s.

    Short remainders are redistributed to avoid <2-second output requests,
    which Wan 3.0 does not accept. Offsets are source-clock aligned.
    """
    try: duration = round(float(duration), 3)
    except (ValueError, TypeError): raise ValueError('Invalid video duration') from None
    if not math.isfinite(duration) or not 2 <= duration <= MAX_SOURCE_SECONDS:
        raise ValueError('Full-video staging supports 2-60 second sources')
    n = int(duration // CLIP_SECONDS)
    rem = round(duration - n * CLIP_SECONDS, 3)
    lengths = [CLIP_SECONDS] * n
    if rem >= 2:
        lengths.append(rem)
    elif rem > 0:
        if not lengths:
            lengths = [duration]
        elif lengths[-1] - (2 - rem) >= 2:
            lengths[-1] = round(lengths[-1] - (2 - rem), 3)
            lengths.append(2.0)
        else:
            lengths[-1] = round(lengths[-1] + rem, 3)
    if not lengths or len(lengths) > MAX_CLIPS:
        raise ValueError('Invalid full-video segment count')
    output = []
    start = 0.0
    for idx, length in enumerate(lengths):
        billed_output = max(2, math.ceil(length - 1e-7))
        if length < 2 or billed_output > 15 or billed_output + math.ceil(length) > 30:
            raise ValueError('Segment cannot be billed safely')
        output.append({'index':idx, 'start':round(start,3), 'duration':round(length,3),
                       'output_seconds':billed_output, 'reused':bool(reuse_first and idx == 0 and length == 3.0),
                       'estimated_usd':round((math.ceil(length) + billed_output) * RATE_USD,2)})
        start = round(start + length,3)
    if abs(start-duration) > 0.003:
        raise ValueError('Full duration not covered')
    return output


def estimate(segments):
    """WaveSpeed model estimate, excludes already archived successful canary."""
    return round(sum(s['estimated_usd'] for s in segments if not s['reused']), 2)


def _reusable_canary(job):
    """Only reuse a previously paid Nicole clip when it matches THIS source/photo.

    A replaced source video or identity photo must invalidate reuse. This function
    performs only DB / private storage reads, never a paid API request.
    """
    job_id=str(job['job_id'])
    step=db.get_step(job_id,FIRST_CANARY_STEP)
    if not step or step.get('state')!='COMPLETED': return False
    media=(step.get('input') or {}).get('payload') or {}
    images=media.get('reference_images') or []
    videos=media.get('reference_videos') or []
    current_image=((job.get('checkpoint') or {}).get('identity') or {}).get('nicole_image_key')
    if not (media.get('duration')==3 and images and videos and current_image): return False
    if current_image not in unquote(urlsplit(images[0]).path): return False
    if f'/recreation/{job_id}/canary/short_reference.mp4' not in unquote(urlsplit(videos[0]).path):return False
    if not _stored(f'recreation/{job_id}/canary/{FIRST_CANARY_STEP}.mp4'): return False
    # Do not reuse if the source MP4 was replaced AFTER that canary was made.
    original=storage.client().head_object(Bucket=storage.bucket(),Key=job['original_key'])
    created=step.get('created_at')
    modified=original.get('LastModified')
    if not created or not modified or modified > created:
        return False
    return True


def report(job):
    """Free estimate without provider calls. Data are read from FFmpeg preflight."""
    preflight=(job.get('checkpoint') or {}).get('local_preflight') or {}
    if preflight.get('source_key')!=job.get('original_key') or not preflight.get('complete'):
        raise ValueError('Archive and finish /preflight before full-video planning')
    source=preflight.get('source_probe') or {}
    segments=plan(source['duration'], reuse_first=_reusable_canary(job))
    if not source.get('has_audio'):
        raise ValueError('Source soundtrack not found; original-audio preservation needs an audio track')
    identity=(job.get('checkpoint') or {}).get('identity') or {}
    if job.get('character')!='NICOLE' or identity.get('status')!='ready' or not identity.get('nicole_image_key'):
        raise ValueError('Nicole private identity reference is required')
    if not (240 <= source['width'] <= 4096 and 240 <= source['height'] <= 4096):
        raise ValueError('Unsupported source dimensions')
    return {'source_duration':source['duration'],'segments':segments,'remaining_estimate_usd':estimate(segments),
            'generated_sections':len([s for s in segments if not s['reused']]),
            'reused_first_canary':bool(segments[0]['reused']), 'audio':'original_source', 'run_key':RUN_KEY}


def _stored(key):
    try:
        storage.client().head_object(Bucket=storage.bucket(),Key=key)
        return True
    except ClientError as exc:
        code=str(exc.response.get('Error',{}).get('Code',''))
        if code in ('404','NoSuchKey','NotFound'):
            return False
        raise


def segment_key(job_id, i):
    return f'recreation/{job_id}/full_video/{RUN_KEY}/segments/{i:03}.mp4'


def source_key(job_id, i):
    return f'recreation/{job_id}/full_video/{RUN_KEY}/inputs/{i:03}.mp4'


def final_key(job_id):
    return f'recreation/{job_id}/full_video/{RUN_KEY}/nicole_with_original_audio.mp4'


def step_key(i):
    return f'wan_{RUN_KEY}_segment_{i:03}'


def _guard_approval(job):
    if os.getenv('WORKER_MODE','')!='full_video_once':
        raise RuntimeError('Full video requires isolated full_video_once worker mode')
    if os.getenv('FULL_VIDEO_ONE_SHOT','false').lower()!='true':
        raise RuntimeError('Full video requires an explicit one-shot flag')
    if os.getenv('ENABLE_PAID_GENERATION','false').lower()!='true':
        raise RuntimeError('Full video paid generation is disabled')
    if os.getenv('ENABLE_PAID_VOICE_GENERATION','false').lower()=='true':
        raise RuntimeError('Paid voiceover is not allowed during original-audio recreation')
    if os.getenv('FULL_VIDEO_APPROVAL_ID') != RUN_KEY:
        raise RuntimeError('Full-video cost approval not configured')
    if os.getenv('FULL_VIDEO_SOURCE_JOB_ID')!=str(job['job_id']):
        raise RuntimeError('Full-video job ID does not match the owner-approved source')
    if not os.getenv('WAVESPEED_API_KEY'):
        raise RuntimeError('WaveSpeed key missing')
    allowed={int(x.strip()) for x in os.getenv('ALLOWED_TELEGRAM_USER_IDS','').split(',') if x.strip().isdigit()}
    if job.get('owner_id') not in allowed or job.get('state')!='DRAFT':
        raise RuntimeError('Full video requires the authorized owner draft')
    metadata=report(job)
    cap_raw=os.getenv('FULL_VIDEO_MAX_USD','')
    try: cap=float(cap_raw)
    except (ValueError,TypeError): raise RuntimeError('An exact full-video USD cap is required') from None
    if not math.isfinite(cap) or cap<=0 or cap>MAX_APPROVAL_USD:
        raise RuntimeError('Full-video USD cap out of allowed bounds')
    if metadata['remaining_estimate_usd']>cap:
        raise RuntimeError('Full-video plan exceeds approved estimated budget')
    return metadata


def _archive_completed_provider(job_id, idx, step):
    output_key=segment_key(job_id,idx)
    if _stored(output_key): return output_key
    if step['state']!='COMPLETED':
        raise ValueError('Cannot archive a non-completed model prediction')
    result=step.get('result') or {}
    urls=result.get('outputs') or []
    if not isinstance(urls,list) or not urls:
        raise provider.NeedsReview('Completed segment lacks an output video')
    storage.store_provider_url(urls[0],output_key)
    return output_key


def _get_reused_first(job_id):
    step=db.get_step(job_id,FIRST_CANARY_STEP)
    if not step or step['state']!='COMPLETED':
        raise RuntimeError('First Nicole segment has no successful saved paid prediction')
    # Validate that the original provider request included the Nicole image.
    payload=(step.get('input') or {}).get('payload') or {}
    if not (payload.get('reference_images') and payload.get('reference_videos') and payload.get('duration')==3):
        raise RuntimeError('First canary is not an identity-specific 3-second result')
    key=f'recreation/{job_id}/canary/{FIRST_CANARY_STEP}.mp4'
    if not _stored(key):
        raise RuntimeError('Already paid Nicole result missing from private storage')
    return key


def _prepare_reference(job, segment):
    job_id=str(job['job_id'])
    key=source_key(job_id,segment['index'])
    if _stored(key): return key
    with tempfile.TemporaryDirectory() as td:
        f=Path(td);src=f/'source.mp4';clip=f/'segment.mp4'
        storage.download_key(job['original_key'],src)
        details=ffmpeg.trim(src,clip,segment['start'],segment['duration'])
        if not (2<=details['duration']<=15) or not (240<=min(details['width'],details['height'])<=4096):
            raise RuntimeError('Input segment failed media validation')
        storage.upload_key(key,clip)
    return key


def _merge_original_sound(job, segments, keys):
    job_id=str(job['job_id']); destination=final_key(job_id)
    if _stored(destination): return destination
    with tempfile.TemporaryDirectory() as td:
        root=Path(td);original=root/'original.mp4';joined=root/'silent_join.mp4';final=root/'final.mp4'
        storage.download_key(job['original_key'],original)
        clips=[]
        for seg,key in zip(segments,keys):
            dest=root/f'seg_{seg["index"]:03}.mp4'
            raw=root/f'raw_{seg["index"]:03}.mp4'
            storage.download_key(key,raw)
            info=ffmpeg.probe(raw)
            if info['duration'] + .12 < seg['duration']:
                raise provider.NeedsReview('Generated clip shorter than the required source segment')
            ffmpeg.trim(raw,dest,0,seg['duration'])
            clips.append(dest)
        ffmpeg.concatenate(clips,joined)
        info=ffmpeg.restore_source_audio(joined,original,final)
        duration_expected=sum(s['duration'] for s in segments)
        if not info['has_audio'] or abs(info['duration']-duration_expected)>.20:
            raise RuntimeError('Final original-audio merge failed duration validation')
        storage.upload_key(destination,final)
    return destination


def run_once():
    job_id=os.getenv('FULL_VIDEO_SOURCE_JOB_ID','')
    if not job_id: raise RuntimeError('Full-video source job not selected')
    job=db.get_job(job_id)
    if not job: raise RuntimeError('Unknown owner draft')
    info=_guard_approval(job)
    segments=info['segments'];keys=[]
    # Re-check approval before EVERY new paid provider request; an operator can
    # disable the service between segments without losing the saved prediction.
    for seg in segments:
        idx=seg['index']
        if seg['reused']:
            keys.append(_get_reused_first(job_id))
            LOGGER.info('FULL_VIDEO existing_first_nicole_segment_reused=true')
            continue
        key=segment_key(job_id,idx)
        if _stored(key):
            keys.append(key);continue
        step=db.get_step(job_id,step_key(idx))
        if step is None:
            _guard_approval(db.get_job(job_id))
            ref=_prepare_reference(job,seg)
            identity=(job['checkpoint'] or {}).get('identity') or {}
            image=storage.presign(identity['nicole_image_key'],3600)
            reference=storage.presign(ref,3600)
            source_media=(job['checkpoint']['local_preflight']['source_probe'])
            payload=wan_canary.payload_for(reference,source_media['width'],source_media['height'],[image])
            payload['duration']=seg['output_seconds']
            LOGGER.info('FULL_VIDEO submitting_segment=%d estimate_usd=%.2f',idx,seg['estimated_usd'])
            step=provider.submit_once(job_id,step_key(idx),wan_canary.MODEL,payload)
            LOGGER.info('FULL_VIDEO submitted_segment=%d prediction_saved=%s',idx,bool(step.get('external_request_id')))
        if step['state'] in ('SUBMITTING','UNCERTAIN','FAILED'):
            raise provider.NeedsReview('Uncertain provider request; manual reconciliation required')
        if step['state']!='COMPLETED':
            result=provider.poll(step)
            if str(result.get('status','')).lower()!='completed':
                LOGGER.info('FULL_VIDEO waiting_for_segment=%d prediction_saved=true',idx)
                return 'processing'
            step=db.get_step(job_id,step_key(idx))
        keys.append(_archive_completed_provider(job_id,idx,step))
        LOGGER.info('FULL_VIDEO saved_segment=%d',idx)
    final=_merge_original_sound(job,segments,keys)
    LOGGER.info('FULL_VIDEO complete=true original_audio=true segments=%d archive_saved=true',len(keys))
    _deliver_once(job,final)
    return 'completed'


def _deliver_once(job, key):
    """At-most-once Telegram DM delivery; archive survives Telegram failure.

    An uncertain sendMessage/sendVideo outcome is never blindly retried.
    """
    job_id=str(job['job_id'])
    delivery_key=f'{RUN_KEY}_telegram_delivery'
    previous=db.get_step(job_id,delivery_key)
    if previous:
        if previous['state']=='COMPLETED': return
        raise provider.NeedsReview('Telegram delivery outcome uncertain; inspect the conversation')
    reserved=db.reserve_one_shot(job_id,delivery_key,'telegram',{'video_key':key,'purpose':'full_video_nicole'})
    if not reserved:
        raise provider.NeedsReview('Telegram delivery was reserved by another worker')
    try:
        result=telegram.telegram('sendVideo',{'chat_id':job['chat_id'], 'video':storage.presign(key,3600),
            'caption':'Nicole recreation finished. Original soundtrack restored. 480p staging.'})
        db.external_finished(job_id,delivery_key,{'message_id':result.get('message_id')})
    except Exception as exc:
        raise provider.NeedsReview('Final file archived, but Telegram delivery needs manual inspection') from exc

