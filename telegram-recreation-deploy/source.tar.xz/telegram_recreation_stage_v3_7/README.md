# Telegram Recreation Studio — standalone n8n-free staging app

This project ports the owner's existing **67-node RECREATION_AGENT_WAN3_REFERENCE_SEGMENTED_IDENTITY_LOCKED_V2_1_MERGE_FIX** pipeline to a Telegram-controlled, durable, independent app. It is separate from Nicole's live Telegram agent, voice calls, Stars, and production memory. Existing n8n workflows remain unchanged.

## Current state — 14 November 2026 · ElevenLabs v4 voice update

Implemented in source:

- Telegram private bot for video uploads, character, scenery, wardrobe, instructions, status, and resume/cancel.
- Persistent PostgreSQL job state, worker leases, webhook deduplication, individual segment outputs, and S3-compatible storage.
- Exact original Gemini forensics and Grok segment-plan requests and parsers, original identity context rules (with sensitive signed URLs removed), original identity-locked Wan prompts and request options, and Gemini QA logic. The trusted frozen scripts are in `recreation/parity_assets.json`, executed by standalone Node (`parity_runner.js`), **without n8n**.
- WaveSpeed binary upload of source media, WaveSpeed LLM analysis, Wan 3.0 reference-to-video submission, saved provider request IDs, read-only polling and restart-safe segment delivery.
- FFmpeg replaces fal.ai trim/concat/audio merge. Outputs are saved durably before advancing. Merged video undergoes source-aware QA before original audio restoration and Telegram delivery.
- **New:** Optional, owner-requested ElevenLabs v4 spoken overlay, with separate locked Nicole and Aria voice IDs and durable, write-ahead billing safety. The original soundtrack remains the default and is restored *before* any optional overlay; no voice cloning or conversion is applied to source speech.
- Source's two `720p` Wan request fields are deliberately overridden to `480p`; prompts, generation seeds, reference roles, and other options remain the source's values.
- Write-ahead `SUBMITTING` states halt on an ambiguous provider response instead of automatically charging twice.
- 25 local tests pass, including an interrupted nine-segment workflow recovering segment seven without resubmitting paid generation.

**Not yet verified and NOT live:** There is no deployed cloud app, no linked private Telegram bot, no live database or object store, no real WaveSpeed model calls, and no tested full video. `ENABLE_PAID_GENERATION=false` and `ENABLE_PAID_VOICE_GENERATION=false` by default. Keep it off until a staging environment has undergone integration tests and the required source-accuracy comparison against n8n.

The 67-node export contains signed image URLs. The package **does not** include it. Instead it includes just the exact trusted source transformation scripts and a sanitized identity-context transformation. Set stable identity references using environment variables. No source credentials are embedded.

## Architecture

`Telegram private bot -> Webhook -> PostgreSQL job -> dedicated worker -> WaveSpeed upload -> Gemini forensics -> Grok segments -> local FFmpeg source trim -> Wan3 initial/continuation -> per-segment S3 -> local FFmpeg merge -> Gemini QA -> FFmpeg original audio -> [optional ElevenLabs v4 spoken overlay] -> S3 -> Telegram`.

The independent worker advances one persisted stage at a time. A paid Wan request has an immutable step key (`wan_segment_000`, `wan_segment_001`, etc.). A restart reclaims a lease and polls the same provider request ID instead of resubmitting. In the rare ambiguity between provider acceptance and saving the ID, the job is paused for manual reconciliation.

## Deployment prerequisites

Provision a **dedicated** PostgreSQL instance and S3-compatible bucket; do not reuse Nicole's production resources. Create a separate BotFather bot and restrict it with `ALLOWED_TELEGRAM_USER_IDS`.

Docker image is built using `telegram-recreation-app/Dockerfile` from repository root. Run web and worker separately from that same image:

- Web: `APP_ROLE=web` exposes port `$PORT` and `/telegram/webhook`; configure `TELEGRAM_WEBHOOK_SECRET` in bot webhook setup.
- Worker: `APP_ROLE=worker` executes the checkpointed pipeline, without an HTTP port. Use a real background worker or equivalent always-on process; don't run a worker on a sleeping free web service.
- Configure the dedicated database and S3 credentials, Telegram token, `WAVESPEED_API_KEY`, `ARIA_IDENTITY_URLS` and/or `NICOLE_IDENTITY_URLS` in secret environment variables. For optional voiceover also configure `ELEVENLABS_API_KEY`; the specific Nicole and Aria voice IDs can be overridden via `ELEVENLABS_VOICE_ID_NICOLE` and `ELEVENLABS_VOICE_ID_ARIA`. Never paste secrets into GitHub.
- Keep `ENABLE_PAID_GENERATION=false` until your controlled staging tests pass. Then explicitly set it to `true` in the staging worker's environment. Keep `ENABLE_PAID_VOICE_GENERATION=false` until separately testing owner-initiated voiceover; ElevenLabs charges separately.
- Telegram cloud Bot API download cap is 20 MB. Use a separately hosted **local Telegram Bot API server** for larger source uploads, with a shared media directory accessible to the worker; set `TELEGRAM_BOT_API_URL`. No change to the existing Nicole bot.
- Large final videos may exceed Telegram's standard outbound limits; test actual file sizes and use local Bot API upload when needed.

## Usage

`/new` -> upload source MP4 -> `/character Nicole` -> `/clothes black dress` -> `/scenery Beirut rooftop at night` -> `/instructions keep all source gestures and timing` -> `/generate` -> `/status`.

Optional: `/voice Nicole` then `/voiceover Good evening, habibi!` before `/generate`. The bot uses **Nicole** voice `DWQWHtcQpAHZJPTy19u1` with **ElevenLabs model `eleven_v4`**. For Aria, use `/character Aria`, optionally `/voice Aria`, then `/voiceover ...`; Aria uses voice `CLyJ3auZqUC7B8ZKF0cF` with the same model. Do not swap their identities or voices. For `/character Aria_Nicole` choose `/voice Nicole` or `/voice Aria` explicitly. `/voiceover off` restores original-audio-only behavior.

**Important:** This optional TTS is an extra spoken overlay, not source-audio transcription, dubbing, lip-sync generation, or voice conversion. It cannot promise mouth synchronization. It never changes the original motion-generation prompts. To keep the original soundtrack intact, leave voiceover off. If enabled, FFmpeg mixes the speech with the original audio after source restoration. The paid ElevenLabs request is atomically reserved before submission (including race protection between workers); ambiguous outcomes require operator review rather than automatic resubmission.

The app itself chooses the original source-faithful Wan reference-video generation path. Kling 4.0 and Seedance 2.5 are **not** advertised as migrated variants because they do not occur in this source workflow and would require separate, validated model-specific adapters. The current published Kling edit minimum may be above 480p; do not silently upscale or mislabel it.

## Local tests

Run after installing `requirements.txt` plus Node.js and FFmpeg:

```bash
PYTHONPATH=telegram-recreation-app pytest -q telegram-recreation-app/tests
```

Tests are fully offline; they **do not prove production integration**. For complete acceptance criteria, see `MIGRATION_CHECKLIST.md`.

### Telegram staging setup (independent bot only)

Save `TELEGRAM_BOT_TOKEN` (or legacy `BOT_TOKEN`), `TELEGRAM_WEBHOOK_SECRET`,
`TELEGRAM_WEBHOOK_URL=https://telegram-recreation-studio-stage.onrender.com/telegram/webhook`
into the **separate** Render staging web service. When the service starts, it
checks bot identity, checks that no *different* webhook is currently assigned,
registers this URL with the Telegram secret-token header, and verifies the result.
It never changes a bot whose webhook points elsewhere.

Visit the new bot in a private chat and send `/id`; it will respond with your Telegram
numeric user ID. Save that in `ALLOWED_TELEGRAM_USER_IDS` on the staging service.
The bot rejects all other chat commands until the allowlist is configured.

Automatic webhook registration uses only the new bot and does not modify other
Telegram bots, Nicole production services, or n8n. Paid API generation remains disabled.
The event log writes only statuses, never tokens or secrets.


## Dedicated FFmpeg staging worker

Use `/preflight` after archiving a video. This queues a safe diagnostic trim/merge, not the original paid Grok/Wan pipeline. A separate Render worker running `WORKER_MODE=preflight_only` records each preview segment to Supabase and resumes after interrupted leases. See `WORKER_STAGING.md`. Paid AI calls remain disabled.
