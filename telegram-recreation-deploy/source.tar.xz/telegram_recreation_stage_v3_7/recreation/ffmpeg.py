"""Local FFmpeg for fal.ai trim/concat/audio equivalence; no fal.ai access needed."""
import json
import subprocess
from pathlib import Path


def run(*args,timeout=600):
    p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
    if p.returncode: raise RuntimeError((p.stderr or '')[-1200:])
    return p.stdout


def probe(file):
    result=json.loads(run('ffprobe','-v','error','-show_format','-show_streams','-of','json',str(file),timeout=40))
    video=next((s for s in result['streams'] if s['codec_type']=='video'),None)
    if not video: raise ValueError('Missing video stream')
    return {'duration':float(result['format'].get('duration') or video.get('duration') or 0),
        'width':int(video['width']),'height':int(video['height']),
        'has_audio':any(s['codec_type']=='audio' for s in result['streams'])}


def trim(source,output,start,duration):
    if float(start)<0 or float(duration)<=0: raise ValueError('Invalid trim interval')
    run('ffmpeg','-hide_banner','-loglevel','error','-y',
        '-ss',str(start),'-i',str(source),'-t',str(duration),
        '-map','0:v:0','-an','-c:v','libx264','-preset','veryfast','-crf','19',
        '-pix_fmt','yuv420p','-movflags','+faststart',str(output))
    return probe(output)


def normalize(source,output,*,width=480,height=854,with_audio=True):
    src=probe(source)
    vf=f'scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=24'
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source)]
    if with_audio and not src['has_audio']:
        cmd+=['-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=44100']
    cmd+=['-map','0:v:0']
    if with_audio: cmd+=['-map','0:a:0' if src['has_audio'] else '1:a:0']
    cmd+=['-vf',vf,'-c:v','libx264','-preset','veryfast','-crf','23',
          '-pix_fmt','yuv420p','-movflags','+faststart']
    if with_audio: cmd+=['-c:a','aac','-ar','44100','-ac','2','-t',str(src['duration'])]
    else:cmd+=['-an']
    run(*cmd,str(output))
    return probe(output)


def concatenate(inputs,output):
    if not inputs: raise ValueError('No input clips')
    folder=Path(output).parent
    parts=[]
    for i,p in enumerate(inputs):
        part=folder/f'norm_{i:03}.mp4'
        normalize(p,part,with_audio=False)
        parts.append(part)
    playlist=folder/'join.txt'
    playlist.write_text(''.join(f"file '{p.resolve()}'\n" for p in parts))
    run('ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0',
        '-i',str(playlist),'-c','copy','-movflags','+faststart',str(output))
    return probe(output)


def restore_source_audio(video,original,output):
    """Copy the video track; use source audio from t=0; pad or cut at final duration."""
    info=probe(video)
    if not probe(original)['has_audio']:
        raise ValueError('The original has no audio; choose silent delivery instead')
    run('ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-i',str(original),
        '-filter_complex','[1:a:0]apad[a]','-map','0:v:0','-map','[a]',
        '-c:v','copy','-c:a','aac','-b:a','192k','-t',str(info['duration']),
        '-movflags','+faststart',str(output))
    return probe(output)


def overlay_voiceover(video_with_original_audio, speech_mp3, output):
    """Explicit opt-in mix: preserve original as one input, add character voice.

    Mix is only used when /voiceover was set. Video stream is copied,
    original soundtrack is retained. Voice clips that exceed video are cut.
    """
    info=probe(video_with_original_audio)
    if not info['has_audio']:
        raise ValueError('Original soundtrack must be restored before optional voiceover')
    run('ffmpeg','-hide_banner','-loglevel','error','-y',
        '-i',str(video_with_original_audio),'-i',str(speech_mp3),
        '-filter_complex',
        '[0:a:0]volume=1[original];[1:a:0]apad[voice];'
        '[original][voice]amix=inputs=2:duration=first:dropout_transition=0:normalize=1[mix]',
        '-map','0:v:0','-map','[mix]',
        '-c:v','copy','-c:a','aac','-b:a','192k',
        '-t',str(info['duration']),'-movflags','+faststart',str(output))
    return probe(output)
