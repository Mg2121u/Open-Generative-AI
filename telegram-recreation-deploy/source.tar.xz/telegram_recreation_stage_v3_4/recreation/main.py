import os
from fastapi import FastAPI
from .telegram import router
from .diagnostics import schedule_startup_probe
from .telegram_setup import bot_token, schedule_registration

app=FastAPI(title='Telegram Recreation Studio',docs_url=None,redoc_url=None)
app.include_router(router)

@app.get('/health')
def health():
    required=('DATABASE_URL','S3_BUCKET','S3_ACCESS_KEY_ID','S3_SECRET_ACCESS_KEY',
              'TELEGRAM_WEBHOOK_SECRET')
    return {'service':'telegram-recreation-app','configured':all(os.getenv(v) for v in required) and bool(bot_token()),
            'generation_ready':False,'status':'staging_only'}

@app.on_event('startup')
def _staging_probe():
    schedule_startup_probe()
    schedule_registration()
