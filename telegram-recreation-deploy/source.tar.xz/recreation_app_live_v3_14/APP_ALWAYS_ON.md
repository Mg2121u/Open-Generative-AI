# Telegram Recreation Studio — always-on owner workflow (v3.14)

This is the **isolated Recreation Studio app**, not the Nicole Telegram production bot. It runs one persistent background worker against the dedicated Recreation Studio Supabase project, using the already-verified WaveSpeed Wan 3.0 reference-to-video endpoint and Nicole identity media. The user may create fresh jobs continuously without opening Render or approving a new one-shot run. Every paid generation must first be explicitly started from the user's authorized Telegram DM via `/generate`.

## Chat workflow

1. `/new` — create fresh job. The latest private, owner-specific Nicole reference photo is carried forward; source MP4 and job outputs are not.
2. Send a source MP4 under the connected cloud Telegram Bot API size limit, or use a properly configured local Telegram Bot API service for larger uploads.
3. Optionally send `/identity` with a reference photo, `/scenery`, `/clothes`, `/instructions`. Default is preserve source wardrobe/background.
4. `/generate` — explicit request to start an individually billable job. The service archives and probes the original, estimates the WaveSpeed charge and posts it to the DM, generates segments in sequence, and delivers the finished MP4 to the same DM.
5. `/status`, `/cancel`, `/resume`, `/preflight`, `/fullplan` also remain available. Provider submissions that are ambiguous/failed are **never automatically duplicated**.

No app-level daily generation count, one-shot run restriction, or old 60-second source cap. Per-model input limits, Telegram upload limits, available compute, provider availability, and pay-per-use charges still apply. A practical 2-hour source processing bound remains for safety, rather than an unlimited processing guarantee. The app is restricted to the authorized owner's Telegram IDs to prevent third-party charges. It currently enables the **Nicole** original-soundtrack recreation path; other characters and new voiceover pipelines are not silently routed through unverified reference prompts.

## Worker configuration

Isolated worker (NOT the Nicole production service): `WORKER_MODE=app_always_on`, `ENABLE_PAID_GENERATION=true`, `ENABLE_PAID_VOICE_GENERATION=false`. It already holds WaveSpeed key and private Supabase/S3 settings. Old one-shot flags remain false/empty and cannot activate a job. `claim_app` restricts claims to owner-started jobs and recognized stages. Web service: `ENABLE_PAID_GENERATION=true`, `ENABLE_PAID_VOICE_GENERATION=false`; webhook and allowed owners stay unchanged. No preexisting DRAFT is processed or charged at startup.

## Continuity and cost safety

- The first segment uses the saved Nicole image and source-video slice.
- Each subsequent request uses **Nicole identity image + the previous generated segment's decoded final frame + the next source-motion slice**.
- Provider request IDs and outputs are durable; collisions/double charges are prevented by one-shot DB reservations for each job/segment.
- 250 ms optical-flow transition at each seam, preserving original soundtrack and source runtime; reject broken seams.
- No automatic paid voice, repeat submission, or per-job Render variable updates. Actual WaveSpeed pricing may differ from the preflight estimate. Every `/generate` is chargeable.

## Verification

Run the Dockerfile integration tests (`PYTHONPATH=/app pytest -q /app/tests`) before activating paid flags. Run read-only deployment/health checks and inspect the worker boot mode after activation. Use a new authorized owner `/new` job to do a complete end-to-end paid canary; **do not create paid user generations merely for deployment testing**.
