"""Offline continuity validation: never submits to WaveSpeed."""
import math
import shutil
import subprocess
from pathlib import Path
from unittest.mock import MagicMock
import pytest
from recreation import full_video, ffmpeg, provider


def job():
    return {'job_id':'job-x','owner_id':123,'chat_id':123,'state':'DRAFT',
            'character':'NICOLE','original_key':'original.mp4',
            'checkpoint':{'identity':{'status':'ready',
                                      'nicole_image_key':'recreation/job-x/identity/nicole.jpg'},
                          'local_preflight':{'source_key':'original.mp4','complete':True,
                              'source_probe':{'width':352,'height':624,'duration':13.9,'has_audio':True}}}}


def urls(idx=1):
    last=full_video.continuity_key('job-x',idx-1)
    identity='recreation/job-x/identity/nicole.jpg'
    source=full_video.source_key('job-x',idx)
    return (f'https://supabase.test/bucket/{source}?sig=1',
            f'https://supabase.test/bucket/{identity}?sig=1',
            f'https://supabase.test/bucket/{last}?sig=1')


def test_chained_payload_includes_previous_frame_plus_identity_and_source_motion():
    source, identity, previous=urls(1)
    payload=full_video.chained_payload(source,identity,previous,352,624,3)
    assert payload['reference_images']==[identity,previous]
    assert payload['reference_videos']==[source]
    assert payload['duration']==3 and payload['resolution']=='480p'
    assert 'Image 1' in payload['prompt'] and 'Image 2' in payload['prompt']
    assert 'LAST FRAME' in payload['prompt'] and 'Video 1' in payload['prompt']
    assert payload['generate_audio'] is False


def test_run_key_is_new_and_old_approval_cannot_enable_regeneration():
    assert full_video.RUN_KEY != 'nicole_full_480p_v1_20261115'
    assert full_video.RUN_KEY in full_video.segment_key('job-x',1)
    assert 'continuity/last_frame_000.png' in full_video.continuity_key('job-x',0)
    assert full_video.RUN_KEY in full_video.step_key(1)


def test_lineage_rejects_old_unchained_or_swapped_inputs():
    seg=full_video.plan(13.9,reuse_first=True)[1]
    src,identity,previous=urls()
    base=full_video.chained_payload(src,identity,previous,352,624,3)
    full_video._validate_chained_step({'input':{'payload':base}},job(),seg,full_video.continuity_key('job-x',0))
    for invalid in ([identity], [previous,identity], [identity,'https://wrong.test/a.png']):
        altered=dict(base,reference_images=invalid)
        with pytest.raises(provider.NeedsReview,match='lineage'):
            full_video._validate_chained_step({'input':{'payload':altered}},job(),seg,full_video.continuity_key('job-x',0))
    altered=dict(base,reference_videos=['https://wrong.test/source.mp4'])
    with pytest.raises(provider.NeedsReview,match='lineage'):
        full_video._validate_chained_step({'input':{'payload':altered}},job(),seg,full_video.continuity_key('job-x',0))


def test_missing_previous_generated_output_fails_before_any_paid_post(monkeypatch):
    monkeypatch.setattr(full_video,'_stored',lambda key:False)
    monkeypatch.setattr(full_video.provider,'submit_once',lambda *args:pytest.fail('paid call attempted'))
    with pytest.raises(provider.NeedsReview,match='Prior Nicole segment missing'):
        full_video._prepare_continuity_frame('job-x',{'index':0,'duration':3},'not-archived.mp4')


def test_severe_raw_seam_pauses_next_paid_job_and_archives_quality_info(monkeypatch,tmp_path):
    reference=full_video.continuity_key('job-x',0)
    generated=full_video.segment_key('job-x',1)
    monkeypatch.setattr(full_video,'_stored',lambda key:False)
    uploads=[]
    monkeypatch.setattr(full_video.storage,'download_key',lambda key,path:Path(path).write_bytes(b'x'*300))
    monkeypatch.setattr(full_video.storage,'upload_key',lambda key,path,mime='video/mp4':uploads.append((key,mime)))
    monkeypatch.setattr(ffmpeg,'extract_first_frame',lambda *a:None)
    monkeypatch.setattr(ffmpeg,'frame_difference',lambda *a:0.85)
    with pytest.raises(provider.NeedsReview,match='Segment boundary differs'):
        full_video._ensure_seam_quality('job-x',{'index':1},reference,generated)
    assert uploads==[(full_video.qa_key('job-x',1),'application/json')]


@pytest.mark.skipif(not shutil.which('ffmpeg'),reason='FFmpeg unavailable')
def test_extracted_last_frame_and_leading_blend_preserve_duration(tmp_path):
    src=tmp_path/'original.mp4';next_clip=tmp_path/'next.mp4'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                    '-f','lavfi','-i','color=c=red:size=320x560:rate=24:duration=2',
                    '-c:v','libx264','-pix_fmt','yuv420p',str(src)],check=True)
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                    '-f','lavfi','-i','color=c=blue:size=320x560:rate=24:duration=2',
                    '-c:v','libx264','-pix_fmt','yuv420p',str(next_clip)],check=True)
    ending=tmp_path/'prev-last.png';beginning=tmp_path/'new-first.png'
    ffmpeg.extract_last_frame(src,ending)
    ffmpeg.extract_first_frame(next_clip,beginning)
    assert ffmpeg.frame_difference(ending,beginning)>0.5
    output=tmp_path/'blended.mp4'
    media=ffmpeg.blend_leading_frame(ending,next_clip,output,seconds=0.167)
    assert abs(media['duration']-2)<0.05 and not media['has_audio']
    assert (media['width'],media['height'])==(480,854)
    new_start=tmp_path/'seam-first.png'
    ffmpeg.extract_first_frame(output,new_start)
    assert ffmpeg.frame_difference(ending,new_start)<0.03

@pytest.mark.skipif(not shutil.which('ffmpeg'),reason='FFmpeg unavailable')
def test_full_assembly_blends_each_boundary_and_restores_original_sound(monkeypatch,tmp_path):
    """All five segments plus prior-frame anchors; no API/provider calls."""
    original=tmp_path/'original.mp4'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
            '-f','lavfi','-i','color=c=red:size=320x560:rate=24:duration=13.9',
            '-f','lavfi','-i','sine=frequency=440:sample_rate=44100:duration=13.9',
            '-c:v','libx264','-preset','ultrafast','-c:a','aac',str(original)],check=True)
    objects={'original.mp4':original}
    parts=full_video.plan(13.9,reuse_first=True)
    keys=[]
    palette=['red','maroon','brown','orange','yellow']
    for idx,seg in enumerate(parts):
        clip=tmp_path/f'generated_{idx}.mp4'
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                '-f','lavfi','-i',f'color=c={palette[idx]}:size=320x560:rate=24:duration={seg["duration"]}',
                '-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',str(clip)],check=True)
        key=full_video.segment_key('job-x',idx)
        objects[key]=clip
        keys.append(key)
    for idx in range(4):
        previous=objects[keys[idx]]
        anchor=tmp_path/f'anchor_{idx}.png'
        ffmpeg.extract_last_frame(previous,anchor)
        objects[full_video.continuity_key('job-x',idx)]=anchor
    monkeypatch.setattr(full_video,'_stored',lambda k:False)
    monkeypatch.setattr(full_video.storage,'download_key',lambda k,d:shutil.copyfile(objects[k],d))
    monkeypatch.setattr(full_video.storage,'upload_key',lambda k,src,mime='video/mp4':objects.update({k:Path(shutil.copyfile(src,tmp_path/'final_archived.mp4'))}))
    monkeypatch.setattr(full_video.provider,'submit_once',lambda *a:pytest.fail('provider used during local assembly'))
    final_key=full_video._merge_original_sound(job(),parts,keys)
    media=ffmpeg.probe(objects[final_key])
    assert media['has_audio'] and (media['width'],media['height'])==(480,854)
    assert abs(media['duration']-13.9)<0.2
