# Faithful migration and reliability acceptance gates

Source export: `RECREATION_AGENT_WAN3_REFERENCE_SEGMENTED_IDENTITY_LOCKED_V2_1_MERGE_FIX.json` (67 nodes). This staging code deliberately excludes the complete export because it contains sensitive signed image URLs. Instead, it contains the relevant **exact original prompt/transform scripts** in `parity_assets.json` and a sanitization-only modification of the identity URL declarations. Do not reintroduce those signed URLs into code.

## Preserve the exact source choreography pipeline

| Checkpoint | Source nodes / semantics | Recovery requirement |
| --- | --- | --- |
| SOURCE | `Build Recreation Context`, `WaveSpeed - Upload Reference Video`, `Prepare Reference Media` | Store original and reference identities durably; never reupload after success |
| FORENSICS | `WaveSpeed Gemini - Video Forensics`, `Parse Gemini Forensics` | Save exact prompt, structured response, and parsed JSON |
| PLANNING | `Grok - Build Segment Plan`, `Parse Grok Segment Plan` | Freeze immutable segment plan, source start/end and output durations |
| SOURCE_TRIM[0] | `fal - Trim First Reference Segment`, `Prepare Initial WAN Segment` | Local FFmpeg replacement; checkpoint source trimmed asset |
| GENERATE[0] | `WaveSpeed WAN 3.0 - Recreate Chunk`, wait/poll result | Use the source's exact prompt and image/video references; persist prediction ID before polling |
| SOURCE_TRIM[i] | `fal - Trim Next Source Segment` | Persist each source cut independently |
| TAIL_TRIM[i] | `fal - Trim Previous Generated Tail` | Previous generated tail is for continuity, not identity or motion override |
| GENERATE[i] | `Prepare Identity-Locked Next WAN Segment`, `WaveSpeed WAN 3.0 - Recreate Next Segment` | Preserve images > physical identity, source video > choreography/timing, previous tail > continuity only |
| CONCAT | `Prepare Segment Merge Decision`, `fal - Merge Generated Reference Segments` | Skip concat for a single segment; use local FFmpeg otherwise; never regenerate previously completed segments |
| QA | `Prepare Gemini QA Request`, `Gemini QA - Original`, `Parse Gemini QA - Original` | Hold manual review on rejection; do not discard previous successful outputs |
| AUDIO | `fal - Merge Original Audio` | Local FFmpeg restores original soundtrack with aligned timestamps; validate audio/video duration |
| OUTPUT | `Prepare Final Published Video`, caption, approval/output | Deliver original quality target via new Telegram bot DM instead of original n8n publishing workflow |

### Deliberate changes only

- Generate at `480p` when provider supports it. Source export currently sends `720p` to both Wan request nodes. Do not modify any other prompt parameter without a parity test.
- Replace fal.ai **trim**, **merge-videos**, and **merge-audio-video** with local FFmpeg; input/output and timing must be checked against original results.
- Replace the form trigger and final posting with Telegram bot input/output. Do not use Nicole's existing service or bot token.
- Move job state from n8n executions into PostgreSQL, store each media artifact in a durable object store.
- Wan 3.0 is the only generation mode evidenced by this exact source export. Seedance and Kling are separate adapters to validate, not automatic substitutions.

### Must-pass reliability simulations before enabling generation

1. Kill a worker immediately after segment 6 completes; restart and verify segment 7 begins, without regenerating segment 1–6.
2. Kill a worker while waiting for Wan; restart, poll the saved provider ID, and never submit a second paid job.
3. Kill a worker after it sends Wan a generation request but before it receives a provider ID; mark `NEEDS_REVIEW`, never blindly re-submit.
4. Make S3 temporarily unavailable; retry only media upload without regenerating video.
5. Feed duplicate Telegram webhook update IDs; create no duplicate jobs.
6. Deliver original 90-second clip: verify source choreography, original audio, duration/beat sync, identity lock, wardrobe/scenery instructions, and no logos or watermarks.
7. Run a source clip larger than 20 MB using an isolated local Telegram Bot API server, then deliver an MP4 via Telegram. Do not reconfigure an existing Nicole bot.
8. Test an explicit QA reject: preserve generated outputs for review rather than deleting or automatically recharging the user.
9. Resume after platform deployment and after a 24-hour outage with refreshed signed URLs.
10. Test at least two shorter clips for output parity before one 60- to 120-second clip; compare original n8n and standalone results.

### Deploy gate

The direct Wan/Gemini/Grok adapter is now implemented in staging source, together with recovery state and FFmpeg delivery. It must remain disabled for paid generation until its full integration is verified against the original n8n workflow, including all of the above simulations. 14 offline unit tests currently pass; no real model generation, production deployment, or payment has been tested.

## ElevenLabs v4 voiceover extension (opt-in, staging)

- [x] Preserve original source audio as default, never substitute synthetic voice automatically.
- [x] Nicole voice ID `DWQWHtcQpAHZJPTy19u1`; Aria voice ID `CLyJ3auZqUC7B8ZKF0cF`.
- [x] Use explicit `model_id=eleven_v4` with `/v1/text-to-speech/{voice_id}`.
- [x] Enforce character/voice matching; require explicit voice selection in duo mode.
- [x] Add Telegram `/voice`, `/voiceover`, `/voiceover off` configuration.
- [x] Add optional post-audio-restoration FFmpeg voice mix; original n8n generation steps unchanged.
- [x] Persist TTS submission intent; completed audio reused; ambiguous submissions require manual review.
- [x] Unit and local FFmpeg tests (25 passing across the staging app).
- [ ] ElevenLabs key and both voice permissions verified in deployed staging (no live API calls yet).
- [ ] Confirm pronunciation, accent, timing and speech mix by listening to real test outputs.
- [ ] Test full source-to-Telegram output with and without optional voiceover and deliberate worker restart.
- [ ] Enable paid voice generation **only after** the above tests and approval.
