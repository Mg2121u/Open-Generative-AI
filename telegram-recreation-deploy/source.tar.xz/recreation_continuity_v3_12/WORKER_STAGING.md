# Dedicated staging worker: safe FFmpeg preflight only

This is a separate Render **background worker**, not a web service. It is deployed from `telegram-recreation-deploy/worker.render.yaml` and deliberately references **existing STAGING Render service environment values** without copying secrets to the repository or to this conversation.

- `WORKER_MODE=preflight_only` forces the worker to claim **only** `LOCAL_PREFLIGHT` jobs. Existing paid provider stages and submitted requests cannot be claimed by this worker.
- `ENABLE_PAID_GENERATION=false` and `ENABLE_PAID_VOICE_GENERATION=false` are enforced for this service. Wan, Gemini, Grok, and ElevenLabs API generation remain disabled.
- `/preflight` queues diagnostics for an already archived draft video. The worker probes the video locally, trims at most three consecutive 4-second source segments, saves each segment and its checkpoint in Supabase, then merges a 480p silent preview and saves that. It retains the original source with audio unchanged in private storage. The preview does not replace the original source or the final reference-to-video workflow.
- Each job stage is persisted to PostgreSQL before the next stage. Interrupted processing can reclaim an expired lease and continue from its saved segment index. Failed FFmpeg work retries with bounded backoff; no paid request is retried.
- Jobs remain DRAFT after preflight, ready for later explicit authorization of paid generation.

## Staging deployment

Blueprint path: `telegram-recreation-deploy/worker.render.yaml` on branch `feature/telegram-video-recreation-app-20261114`.

Render compute: `0.5c-512mb` background worker, currently listed at **$7/month**. The worker's environment variables are sourced from the **existing** `telegram-recreation-studio-stage` service. This Blueprint contains *no* Nicole production secrets and creates *only one* worker service. `autoDeployTrigger: off`, `autoSync: false`.

Before approving the Blueprint, inspect its plan; the initial plan must not include any changes to Nicole services or the existing recreation web service. This separate paid worker must not be approved without the user's confirmation of the reviewed plan.
