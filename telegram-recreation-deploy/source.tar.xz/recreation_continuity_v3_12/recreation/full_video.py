"""Staging-only, restart-safe full-video Nicole recreation.

No billable calls unless an exact cost approval is configured on the *dedicated*
worker. Reuse the already approved and successfully archived first 3-second
Nicole identity segment, generating only subsequent source windows. Each segment
has an immutable provider step key and cannot be paid twice automatically.
The final sound is copied from the original archived video via FFmpeg.
"""
import logging
import json
import math
import os
import tempfile
from pathlib import Path
from urllib.parse import urlsplit, unquote

from botocore.exceptions import ClientError

from . import db, ffmpeg, provider, storage, wan_canary, telegram

LOGGER = logging.getLogger('full-video')
RUN_KEY = 'nicole_full_480p_v2_chained_20261115'
FIRST_CANARY_STEP = wan_canary.STEP_KEY
MAX_SOURCE_SECONDS = 60.0
MAX_CLIPS = 24
CLIP_SECONDS = 3.0
RATE_USD = 0.05
# An approval for the first single-clip canary is NOT an approval for the full video.
MAX_APPROVAL_USD = 10.0
# The previous generated ending is guidance, not a strict Wan first_frame input.
# The actual first output frames are corrected locally after seam QA.
SEAM_BLEND_SECONDS = 0.167
MAX_RAW_SEAM_MAE = 0.35  # measured normalized RGB mean absolute error (0..1)


def plan(duration, *, reuse_first=False):
    """Split the *entire* duration, with each reference 2-3.99s.

    Short remainders are redistributed to avoid <2-second output requests,
    which Wan 3.0 does not accept. Offsets are source-clock aligned.
    """
    try: duration = round(float(duration), 3)
    except (ValueError, TypeError): raise ValueError('Invalid video duration') from None
    if not math.isfinite(duration) or not 2 <= duration <= MAX_SOURCE_SECONDS:
        raise ValueError('Full-video staging supports 2-60 second sources')
    n = int(duration // CLIP_SECONDS)
    rem = round(duration - n * CLIP_SECONDS, 3)
    lengths = [CLIP_SECONDS] * n
    if rem >= 2:
        lengths.append(rem)
    elif rem > 0:
        if not lengths:
            lengths = [duration]
        elif lengths[-1] - (2 - rem) >= 2:
            lengths[-1] = round(lengths[-1] - (2 - rem), 3)
            lengths.append(2.0)
        else:
            lengths[-1] = round(lengths[-1] + rem, 3)
    if not lengths or len(lengths) > MAX_CLIPS:
        raise ValueError('Invalid full-video segment count')
    output = []
    start = 0.0
    for idx, length in enumerate(lengths):
        billed_output = max(2, math.ceil(length - 1e-7))
        if length < 2 or billed_output > 15 or billed_output + math.ceil(length) > 30:
            raise ValueError('Segment cannot be billed safely')
        output.append({'index':idx, 'start':round(start,3), 'duration':round(length,3),
                       'output_seconds':billed_output, 'reused':bool(reuse_first and idx == 0 and length == 3.0),
                       'estimated_usd':round((math.ceil(length) + billed_output) * RATE_USD,2)})
        start = round(start + length,3)
    if abs(start-duration) > 0.003:
        raise ValueError('Full duration not covered')
    return output


def estimate(segments):
    """WaveSpeed model estimate, excludes already archived successful canary."""
    return round(sum(s['estimated_usd'] for s in segments if not s['reused']), 2)


def _reusable_canary(job):
    """Only reuse a previously paid Nicole clip when it matches THIS source/photo.

    A replaced source video or identity photo must invalidate reuse. This function
    performs only DB / private storage reads, never a paid API request.
    """
    job_id=str(job['job_id'])
    step=db.get_step(job_id,FIRST_CANARY_STEP)
    if not step or step.get('state')!='COMPLETED': return False
    media=(step.get('input') or {}).get('payload') or {}
    images=media.get('reference_images') or []
    videos=media.get('reference_videos') or []
    current_image=((job.get('checkpoint') or {}).get('identity') or {}).get('nicole_image_key')
    if not (media.get('duration')==3 and images and videos and current_image): return False
    if current_image not in unquote(urlsplit(images[0]).path): return False
    if f'/recreation/{job_id}/canary/short_reference.mp4' not in unquote(urlsplit(videos[0]).path):return False
    if not _stored(f'recreation/{job_id}/canary/{FIRST_CANARY_STEP}.mp4'): return False
    # Do not reuse if the source MP4 was replaced AFTER that canary was made.
    original=storage.client().head_object(Bucket=storage.bucket(),Key=job['original_key'])
    created=step.get('created_at')
    modified=original.get('LastModified')
    if not created or not modified or modified > created:
        return False
    return True


def report(job):
    """Free estimate without provider calls. Data are read from FFmpeg preflight."""
    preflight=(job.get('checkpoint') or {}).get('local_preflight') or {}
    if preflight.get('source_key')!=job.get('original_key') or not preflight.get('complete'):
        raise ValueError('Archive and finish /preflight before full-video planning')
    source=preflight.get('source_probe') or {}
    if not source.get('has_audio'):
        raise ValueError('Source soundtrack not found; original-audio preservation needs an audio track')
    identity=(job.get('checkpoint') or {}).get('identity') or {}
    if job.get('character')!='NICOLE' or identity.get('status')!='ready' or not identity.get('nicole_image_key'):
        raise ValueError('Nicole private identity reference is required')
    if not (240 <= source['width'] <= 4096 and 240 <= source['height'] <= 4096):
        raise ValueError('Unsupported source dimensions')
    segments=plan(source['duration'],reuse_first=_reusable_canary(job))
    return {'source_duration':source['duration'],'segments':segments,'remaining_estimate_usd':estimate(segments),
            'generated_sections':len([s for s in segments if not s['reused']]),
            'reused_first_canary':bool(segments[0]['reused']), 'audio':'original_source', 'run_key':RUN_KEY,
            'continuity':'previous_generated_last_frame_reference_plus_short_boundary_blend',
            'strict_wan_first_frame':False}


def _stored(key):
    try:
        storage.client().head_object(Bucket=storage.bucket(),Key=key)
        return True
    except ClientError as exc:
        code=str(exc.response.get('Error',{}).get('Code',''))
        if code in ('404','NoSuchKey','NotFound'):
            return False
        raise


def segment_key(job_id, i):
    return f'recreation/{job_id}/full_video/{RUN_KEY}/segments/{i:03}.mp4'


def source_key(job_id, i):
    return f'recreation/{job_id}/full_video/{RUN_KEY}/inputs/{i:03}.mp4'


def final_key(job_id):
    return f'recreation/{job_id}/full_video/{RUN_KEY}/nicole_with_original_audio.mp4'


def continuity_key(job_id, previous_idx):
    """Deterministic image made from the LAST displayed frame of prior clip."""
    return f'recreation/{job_id}/full_video/{RUN_KEY}/continuity/last_frame_{previous_idx:03}.png'


def qa_key(job_id, idx):
    return f'recreation/{job_id}/full_video/{RUN_KEY}/continuity/qa_{idx:03}.json'


def step_key(i):
    return f'wan_{RUN_KEY}_segment_{i:03}'


def _guard_approval(job):
    if os.getenv('WORKER_MODE','')!='full_video_once':
        raise RuntimeError('Full video requires isolated full_video_once worker mode')
    if os.getenv('FULL_VIDEO_ONE_SHOT','false').lower()!='true':
        raise RuntimeError('Full video requires an explicit one-shot flag')
    if os.getenv('ENABLE_PAID_GENERATION','false').lower()!='true':
        raise RuntimeError('Full video paid generation is disabled')
    if os.getenv('ENABLE_PAID_VOICE_GENERATION','false').lower()=='true':
        raise RuntimeError('Paid voiceover is not allowed during original-audio recreation')
    if os.getenv('FULL_VIDEO_APPROVAL_ID') != RUN_KEY:
        raise RuntimeError('Full-video cost approval not configured')
    if os.getenv('FULL_VIDEO_SOURCE_JOB_ID')!=str(job['job_id']):
        raise RuntimeError('Full-video job ID does not match the owner-approved source')
    if not os.getenv('WAVESPEED_API_KEY'):
        raise RuntimeError('WaveSpeed key missing')
    allowed={int(x.strip()) for x in os.getenv('ALLOWED_TELEGRAM_USER_IDS','').split(',') if x.strip().isdigit()}
    if job.get('owner_id') not in allowed or job.get('state')!='DRAFT':
        raise RuntimeError('Full video requires the authorized owner draft')
    metadata=report(job)
    cap_raw=os.getenv('FULL_VIDEO_MAX_USD','')
    try: cap=float(cap_raw)
    except (ValueError,TypeError): raise RuntimeError('An exact full-video USD cap is required') from None
    if not math.isfinite(cap) or cap<=0 or cap>MAX_APPROVAL_USD:
        raise RuntimeError('Full-video USD cap out of allowed bounds')
    if metadata['remaining_estimate_usd']>cap:
        raise RuntimeError('Full-video plan exceeds approved estimated budget')
    return metadata


def _archive_completed_provider(job_id, idx, step):
    output_key=segment_key(job_id,idx)
    if _stored(output_key): return output_key
    if step['state']!='COMPLETED':
        raise ValueError('Cannot archive a non-completed model prediction')
    result=step.get('result') or {}
    urls=result.get('outputs') or []
    if not isinstance(urls,list) or not urls:
        raise provider.NeedsReview('Completed segment lacks an output video')
    storage.store_provider_url(urls[0],output_key)
    return output_key


def _get_reused_first(job_id):
    step=db.get_step(job_id,FIRST_CANARY_STEP)
    if not step or step['state']!='COMPLETED':
        raise RuntimeError('First Nicole segment has no successful saved paid prediction')
    # Validate that the original provider request included the Nicole image.
    payload=(step.get('input') or {}).get('payload') or {}
    if not (payload.get('reference_images') and payload.get('reference_videos') and payload.get('duration')==3):
        raise RuntimeError('First canary is not an identity-specific 3-second result')
    key=f'recreation/{job_id}/canary/{FIRST_CANARY_STEP}.mp4'
    if not _stored(key):
        raise RuntimeError('Already paid Nicole result missing from private storage')
    return key


def _prepare_reference(job, segment):
    job_id=str(job['job_id'])
    key=source_key(job_id,segment['index'])
    if _stored(key): return key
    with tempfile.TemporaryDirectory() as td:
        f=Path(td);src=f/'source.mp4';clip=f/'segment.mp4'
        storage.download_key(job['original_key'],src)
        details=ffmpeg.trim(src,clip,segment['start'],segment['duration'])
        if not (2<=details['duration']<=15) or not (240<=min(details['width'],details['height'])<=4096):
            raise RuntimeError('Input segment failed media validation')
        storage.upload_key(key,clip)
    return key


def _prepare_continuity_frame(job_id, previous_seg, previous_video_key):
    """Archive exact preceding GENERATED end frame before the NEXT paid POST.

    The preceding file can be the successful Nicole canary, or a generated
    segment from this run. Never derive the image from the original performer.
    Trim first: the last frame must match the actual displayed join point.
    """
    if not previous_seg or not previous_video_key or not _stored(previous_video_key):
        raise provider.NeedsReview('Prior Nicole segment missing; cannot submit next paid segment')
    img_key=continuity_key(job_id,previous_seg['index'])
    if _stored(img_key): return img_key
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        raw=root/'previous.mp4';cut=root/'previous_trim.mp4';out=root/'previous_last.png'
        storage.download_key(previous_video_key,raw)
        probe=ffmpeg.probe(raw)
        if probe['duration'] + .12 < previous_seg['duration']:
            raise provider.NeedsReview('Previous generated clip is too short for continuity extraction')
        ffmpeg.trim(raw,cut,0,previous_seg['duration'])
        ffmpeg.extract_last_frame(cut,out)
        storage.upload_key(img_key,out,mime='image/png')
    return img_key


def chained_payload(video_url, identity_url, previous_last_frame_url, width, height, seconds):
    """Use reference mode: Nicole=Image 1, prior generated end=Image 2.

    Wan's strict image-to-video first_frame route does not accept a video
    reference alongside its first_frame. This is explicit *soft* conditioning,
    with deterministic seam handling after generation.
    """
    payload=wan_canary.payload_for(video_url,width,height,[identity_url,previous_last_frame_url])
    payload['duration']=seconds
    payload['prompt']=(
        'IDENTITY AND CONTINUITY: Image 1 is Nicole. She is the ONLY performer and '
        'her face, hair, skin, body and identity must match Image 1, NOT the woman '
        'in Video 1. Image 2 is the EXACT LAST FRAME OF THE PREVIOUS GENERATED '
        'NICOLE CLIP. Start this video in the SAME visual state as Image 2: '
        'same Nicole pose, head and hand positions, clothes, framing, perspective, '
        'background, shadows, lighting and camera location. NO sudden resets, '
        'outfit changes, cuts, camera jumps or person swaps at the beginning. '
        'Continue the movement fluidly from Image 2. Video 1 is ONLY the NEXT '
        'source time-window for motion, gestures, choreography and scene timing. '
        'Recreate that source motion with Nicole while preserving the previous '
        'clip ending as the start. Do not copy the source person identity. '
        'No new people, words, logos or watermarks.'
    )
    return payload


def _validate_chained_step(step, job, segment, prev_img_key):
    """Prevent old or unrelated provider predictions from silently being reused."""
    payload=((step or {}).get('input') or {}).get('payload') or {}
    images=payload.get('reference_images') or []
    videos=payload.get('reference_videos') or []
    identity=((job.get('checkpoint') or {}).get('identity') or {}).get('nicole_image_key')
    def contains_key(url, key):
        return isinstance(url,str) and isinstance(key,str) and key in unquote(urlsplit(url).path)
    if (len(images)!=2 or len(videos)!=1 or not identity
        or not contains_key(images[0],identity)
        or not contains_key(images[1],prev_img_key)
        or not contains_key(videos[0],source_key(str(job['job_id']),segment['index']))
        or payload.get('duration')!=segment['output_seconds']):
        raise provider.NeedsReview('Saved segment has incorrect Nicole/previous-frame/source lineage')


def _ensure_seam_quality(job_id, seg, previous_frame_key, generated_key):
    """Evaluate *raw* model seam before a costly subsequent generation.

    This does not claim pixel-exact Wan conditioning. A severe raw seam stops
    before more paid segments; minor discontinuity gets a short local blend.
    """
    saved=qa_key(job_id,seg['index'])
    if _stored(saved):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'seam.json';storage.download_key(saved,path)
            record=json.loads(path.read_text())
            if record.get('previous_frame_key')!=previous_frame_key or record.get('output_key')!=generated_key:
                raise provider.NeedsReview('Seam QA belongs to another input or output')
            value=float(record.get('raw_mae',1))
    else:
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);prev=root/'last.png';clip=root/'next.mp4';first=root/'first.png'
            storage.download_key(previous_frame_key,prev)
            storage.download_key(generated_key,clip)
            ffmpeg.extract_first_frame(clip,first)
            value=ffmpeg.frame_difference(prev,first)
            record={'previous_frame_key':previous_frame_key,'output_key':generated_key,
                    'raw_mae':round(value,5),'review_threshold':MAX_RAW_SEAM_MAE,
                    'wan_first_frame_guaranteed':False,'blend_seconds':SEAM_BLEND_SECONDS}
            artifact=root/'qa.json';artifact.write_text(json.dumps(record,sort_keys=True))
            storage.upload_key(saved,artifact,mime='application/json')
    LOGGER.info('FULL_VIDEO seam_checked=%d raw_mae=%.3f',seg['index'],value)
    if not (0<=value<=MAX_RAW_SEAM_MAE):
        raise provider.NeedsReview('Segment boundary differs too much; paused for visual QA before further paid requests')
    return value


def _merge_original_sound(job, segments, keys):
    job_id=str(job['job_id']); destination=final_key(job_id)
    if _stored(destination): return destination
    with tempfile.TemporaryDirectory() as td:
        root=Path(td);original=root/'original.mp4';joined=root/'silent_join.mp4';final=root/'final.mp4'
        storage.download_key(job['original_key'],original)
        clips=[]
        for seg,key in zip(segments,keys):
            dest=root/f'seg_{seg["index"]:03}.mp4'
            raw=root/f'raw_{seg["index"]:03}.mp4'
            storage.download_key(key,raw)
            info=ffmpeg.probe(raw)
            if info['duration'] + .12 < seg['duration']:
                raise provider.NeedsReview('Generated clip shorter than the required source segment')
            ffmpeg.trim(raw,dest,0,seg['duration'])
            if seg['index']>0:
                frame=root/f'previous_frame_{seg["index"]-1:03}.png'
                storage.download_key(continuity_key(job_id,seg['index']-1),frame)
                smooth=root/f'smoothed_{seg["index"]:03}.mp4'
                ffmpeg.blend_leading_frame(frame,dest,smooth,seconds=SEAM_BLEND_SECONDS)
                dest=smooth
            clips.append(dest)
        ffmpeg.concatenate(clips,joined)
        info=ffmpeg.restore_source_audio(joined,original,final)
        duration_expected=sum(s['duration'] for s in segments)
        if not info['has_audio'] or abs(info['duration']-duration_expected)>.20:
            raise RuntimeError('Final original-audio merge failed duration validation')
        storage.upload_key(destination,final)
    return destination


def run_once():
    job_id=os.getenv('FULL_VIDEO_SOURCE_JOB_ID','')
    if not job_id: raise RuntimeError('Full-video source job not selected')
    job=db.get_job(job_id)
    if not job: raise RuntimeError('Unknown owner draft')
    info=_guard_approval(job)
    segments=info['segments'];keys=[]
    # Re-check approval before EVERY new paid provider request; an operator can
    # disable the service between segments without losing the saved prediction.
    for seg in segments:
        idx=seg['index']
        if seg['reused']:
            keys.append(_get_reused_first(job_id))
            LOGGER.info('FULL_VIDEO existing_first_nicole_segment_reused=true')
            continue
        # The actual final displayed frame from the PREVIOUS GENERATED CLIP
        # must exist before ANY new provider request can be submitted.
        if idx<1 or len(keys)!=idx:
            raise provider.NeedsReview('Continuity ordering mismatch; paid submission blocked')
        prev_img_key=_prepare_continuity_frame(job_id,segments[idx-1],keys[-1])
        key=segment_key(job_id,idx)
        step=db.get_step(job_id,step_key(idx))
        if step:
            _validate_chained_step(step,job,seg,prev_img_key)
        if _stored(key):
            if not step or step.get('state')!='COMPLETED':
                raise provider.NeedsReview('Stored output is not tied to a completed chained prediction')
            _ensure_seam_quality(job_id,seg,prev_img_key,key)
            keys.append(key)
            continue
        if step is None:
            _guard_approval(db.get_job(job_id))
            ref=_prepare_reference(job,seg)
            identity=(job['checkpoint'] or {}).get('identity') or {}
            image=storage.presign(identity['nicole_image_key'],3600)
            previous=storage.presign(prev_img_key,3600)
            reference=storage.presign(ref,3600)
            source_media=(job['checkpoint']['local_preflight']['source_probe'])
            payload=chained_payload(reference,image,previous,source_media['width'],source_media['height'],seg['output_seconds'])
            LOGGER.info('FULL_VIDEO submitting_chained_segment=%d estimate_usd=%.2f',idx,seg['estimated_usd'])
            step=provider.submit_once(job_id,step_key(idx),wan_canary.MODEL,payload)
            LOGGER.info('FULL_VIDEO submitted_segment=%d prediction_saved=%s',idx,bool(step.get('external_request_id')))
        if step['state'] in ('SUBMITTING','UNCERTAIN','FAILED'):
            raise provider.NeedsReview('Uncertain provider request; manual reconciliation required')
        if step['state']!='COMPLETED':
            result=provider.poll(step)
            if str(result.get('status','')).lower()!='completed':
                LOGGER.info('FULL_VIDEO waiting_for_segment=%d prediction_saved=true',idx)
                return 'processing'
            step=db.get_step(job_id,step_key(idx))
        saved_key=_archive_completed_provider(job_id,idx,step)
        _ensure_seam_quality(job_id,seg,prev_img_key,saved_key)
        keys.append(saved_key)
        LOGGER.info('FULL_VIDEO saved_chained_segment=%d',idx)
    final=_merge_original_sound(job,segments,keys)
    LOGGER.info('FULL_VIDEO complete=true original_audio=true segments=%d archive_saved=true',len(keys))
    _deliver_once(job,final)
    return 'completed'


def _deliver_once(job, key):
    """At-most-once Telegram DM delivery; archive survives Telegram failure.

    An uncertain sendMessage/sendVideo outcome is never blindly retried.
    """
    job_id=str(job['job_id'])
    delivery_key=f'{RUN_KEY}_telegram_delivery'
    previous=db.get_step(job_id,delivery_key)
    if previous:
        if previous['state']=='COMPLETED': return
        raise provider.NeedsReview('Telegram delivery outcome uncertain; inspect the conversation')
    reserved=db.reserve_one_shot(job_id,delivery_key,'telegram',{'video_key':key,'purpose':'full_video_nicole'})
    if not reserved:
        raise provider.NeedsReview('Telegram delivery was reserved by another worker')
    try:
        result=telegram.telegram('sendVideo',{'chat_id':job['chat_id'], 'video':storage.presign(key,3600),
            'caption':'Nicole recreation finished. Original soundtrack restored. 480p staging.'})
        db.external_finished(job_id,delivery_key,{'message_id':result.get('message_id')})
    except Exception as exc:
        raise provider.NeedsReview('Final file archived, but Telegram delivery needs manual inspection') from exc

