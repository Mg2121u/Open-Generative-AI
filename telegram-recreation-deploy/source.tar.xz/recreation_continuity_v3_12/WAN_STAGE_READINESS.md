# Wan 3.0 provider stage — staging safeguards (2026-11-15)

This release preserves the original 67-node n8n-derived transformation scripts and the 480p output constraint. No production n8n or Nicole bot resources are modified.

## Changes

- Every paid or externally billed call is gated by `ENABLE_PAID_GENERATION=true`. Worker remains `WORKER_MODE=preflight_only` and both paid generation flags remain `false` in the deployed stage.
- WaveSpeed reference-to-video submissions are restricted to the expected model ID and 480p payload with a reference video and prompt.
- A PostgreSQL `INSERT ... ON CONFLICT DO NOTHING` reservation is required before any external POST. A failed reservation blocks a second network call even when two workers observed an absent step concurrently.
- Ambiguous POST responses, missing prediction IDs, unexpected semantic status codes, and terminal `failed`, `cancelled`, `timeout`, `deleted` predictions are routed to manual review rather than automatic repeat billing.
- Requests to poll an existing prediction ID remain safe and do not perform another POST.
- Source media upload, paid LLM calls and final Telegram delivery now check the result of their one-shot reservation; a concurrent second attempt does not send duplicate traffic.

## Verification

- Unit-tested fake WaveSpeed responses and a fake DB for no-charge submission, conflict, processing, result-terminal handling, and stage transitions.
- 58 tests passed and one optional test skipped locally; no real WaveSpeed or ElevenLabs calls were made.
- Live worker remains `preflight_only`; deployment requires no external-model credentials or new subscriptions.

## Not yet established

- The real WaveSpeed Wan 3.0 call and result formats have **not** been tested against a paid job.
- The full 67-node sequence remains unverified as one end-to-end generation.
- Before any paid canary: verify provider API key, owner-only approval, reference-image URLs, model parameters and current price; authorize a bounded budget; monitor submission and output quality.
