# Nicole chain-of-frames full-video staging v2 — November 15, 2026

## Problem fixed

The first complete Nicole video used identity-correct source reference clips but generated each interval independently; at join boundaries Nicole could change pose, viewpoint, or lighting. The user specifically requested conditioning every subsequent generation on the last **generated** frame of the previous clip.

## Design

- For the FIRST clip, reuse the previously approved Nicole 3-second canary **only if the archive source and Nicole image still match**. This gives an identity-correct first segment without paying twice.
- Before generating each subsequent interval, download the preceding completed **Nicole-generated** segment from private storage; trim it to the exact displayed duration; extract its LAST DECODED frame (PNG) using FFmpeg; save it to `full_video/{run_key}/continuity/last_frame_NNN.png`.
- Wan3 `reference_images` must contain Image 1 = Nicole's full identity reference; Image 2 = exact preceding generated last frame. Wan3 `reference_videos` contains Video 1 = next original source time-window, for movement/camera and timing. Prompt calls out these distinct roles. The image comes from the previous **generated** Nicole clip, never from the original performer.
- Enforce dependency ordering: segment N+1 cannot submit before segment N was saved and its last frame archived. Each new provider step has a unique immutable key and write-ahead reservation, and stored steps are checked for correct identity, source, and previous-frame lineage. Never automatically repeat a paid POST after uncertain submission.
- After each output, compare the preceding last frame against the new **raw** first frame, recording a normalized mean absolute pixel error privately. A severe mismatch (`>0.35`) pauses the workflow for owner review before any additional paid requests. This is a heuristic threshold, not a perceptual guarantee.
- During local merge, for each subsequent clip use a **167ms** ease-in blend from the preceding generated frame into its opening frames. This preserves the intended segment duration; no overlap shortening or audio timing shifts. Restore the archived original soundtrack from time zero in the final 480p MP4.

## Wan API limitation

Wan3 reference-to-video allows several reference images/videos, but **does not guarantee Image 2 will be exactly reproduced as its first video frame**. Its separate image-to-video API can strictly anchor the first frame, but first_frame cannot be combined with reference_video and Nicole identity reference in the same native Wan3 API request. This workflow retains the proven motion and identity reference route, then applies local seam smoothing, not an unverified claim of flawless generation. Testing actual v2 generated clips is required.

## Charge protection

New run key: `nicole_full_480p_v2_chained_20261115`. The previous v1 paid run, outputs, and Telegram message remain unchanged. The 2026-11-15 $1.50 v1 approval **does not** activate v2. The code defaults to worker mode `preflight_only`, `FULL_VIDEO_ONE_SHOT=false`, `ENABLE_PAID_GENERATION=false`. A *fresh, explicit* owner budget approval and exact v2 approval ID are required before any additional WaveSpeed generations. Original four v1 generated segments are preserved but **not falsely represented as chained**. Actual model billing and aesthetic quality remain to be verified.

## Validations

Offline unit tests cover reference roles and ordering, missing previous clip fail-closed, completed step lineage check, raw-seam QA pause, last decoded frame extraction, stable blending duration, and a complete 13.9-second five-part FFmpeg merge with source audio. Render's Docker build must also pass the full suite before staging deploy. No WaveSpeed calls during this update.
