-- Dedicated database for Telegram Recreation. Do not run against Nicole's production database.
CREATE TABLE IF NOT EXISTS recreation_jobs (
  job_id uuid PRIMARY KEY,
  chat_id bigint NOT NULL,
  owner_id bigint NOT NULL,
  character text NOT NULL DEFAULT 'NICOLE',
  model text NOT NULL DEFAULT 'wan-3.0',
  resolution text NOT NULL DEFAULT '480p',
  source_file_id text,
  original_key text,
  outfit text NOT NULL DEFAULT 'keep source clothing',
  scenery text NOT NULL DEFAULT 'keep source scenery',
  instructions text NOT NULL DEFAULT '',
  voiceover_text text NOT NULL DEFAULT '',
  voiceover_voice text NOT NULL DEFAULT 'AUTO',
  CHECK (voiceover_voice IN ('AUTO','NICOLE','ARIA')),
  state text NOT NULL DEFAULT 'DRAFT',
  stage text NOT NULL DEFAULT 'UPLOAD',
  current_segment integer NOT NULL DEFAULT 0,
  segment_total integer NOT NULL DEFAULT 0,
  outputs jsonb NOT NULL DEFAULT '[]'::jsonb,
  checkpoint jsonb NOT NULL DEFAULT '{}'::jsonb,
  last_error text,
  attempt integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  lease_owner text,
  lease_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (state IN ('DRAFT','QUEUED','RUNNING','WAITING_PROVIDER','FAILED','NEEDS_REVIEW','CANCELLED','COMPLETED')),
  CHECK (resolution = '480p')
);
CREATE INDEX IF NOT EXISTS recreation_jobs_claim ON recreation_jobs(state,next_attempt_at,lease_until);
CREATE INDEX IF NOT EXISTS recreation_jobs_owner ON recreation_jobs(owner_id,created_at DESC);

CREATE TABLE IF NOT EXISTS recreation_steps (
  job_id uuid NOT NULL REFERENCES recreation_jobs(job_id) ON DELETE CASCADE,
  step_key text NOT NULL,
  state text NOT NULL CHECK(state IN ('READY','SUBMITTING','SUBMITTED','POLLING','COMPLETED','FAILED','UNCERTAIN')),
  provider text,
  external_request_id text,
  input jsonb NOT NULL DEFAULT '{}'::jsonb,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  attempts integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(job_id,step_key)
);
CREATE TABLE IF NOT EXISTS recreation_updates (
  update_id bigint PRIMARY KEY,
  received_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS recreation_events (
  event_id bigserial PRIMARY KEY,
  job_id uuid NOT NULL REFERENCES recreation_jobs(job_id) ON DELETE CASCADE,
  kind text NOT NULL,
  description text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Existing staging database upgrades (run once if the app was already installed):
ALTER TABLE recreation_jobs ADD COLUMN IF NOT EXISTS voiceover_text text NOT NULL DEFAULT '';
ALTER TABLE recreation_jobs ADD COLUMN IF NOT EXISTS voiceover_voice text NOT NULL DEFAULT 'AUTO';
