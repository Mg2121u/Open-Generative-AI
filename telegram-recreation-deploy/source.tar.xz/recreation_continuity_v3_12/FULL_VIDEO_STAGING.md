# Nicole full-video staging: chained-frame continuity v2 (disabled by default)

## Why this change exists

The first 13.9-second Nicole video generated 5 independent segments. Nicole's
identity was correct, but frames near the joins could jump because each new Wan
request only saw Nicole's portrait and its separate original-video motion slice.

**v2 makes each segment depend on the previous GENERATED segment**, never on the
source video's final frame. It still uses the verified reference-to-video route,
so movement and camera guidance continue to come from the original source clip.

For each of the 4 segments after the first:

1. Retrieve the previous generated MP4 from private Supabase storage.
2. Decode its *actual last video frame* with FFmpeg, store the JPEG privately
   under a durable continuity checkpoint, and reuse it after restarts.
3. Build the supported Wan 3.0 reference-to-video request with 2 images and 1
   video: **Image 1 = Nicole's identity**, **Image 2 = the preceding generated
   last frame**, **Video 1 = the next original-source motion slice**.
4. The prompt directs Wan to continue its shot from Image 2 without changing
   pose, camera, outfit, scene, or subject identity. The output has no AI audio.
5. Save the resulting prediction ID before polling and persist the completed
   segment. The next new request cannot submit without its predecessor.
6. At final assembly, a **200ms FFmpeg blend-in** starts each new segment with
   the previous generated final frame. This locally enforces the cut's first
   visible frame and avoids lengthening or shortening the segment. A seam QC
   check rejects a cut if the first displayed frame differs too much.
7. Restore the original video soundtrack against the 13.9-second output, then
   privately archive and deliver it via the separate staging Telegram DM.

## Model limitation and accuracy

WaveSpeed's `alibaba/wan-3.0/reference-to-video` endpoint does **not** expose a
strict `first_frame` input when also using reference video for source motion.
Only image-to-video supports exact opening-frame controls, and that route
cannot combine its first-frame input with the reference-video material.
Thus **Image 2 is model guidance rather than a strict pixel constraint**;
local FFmpeg blending anchors the seam after generation, but visual motion
continuity remains subject to output review. The blend is only 0.2 seconds
and can create transient ghosting for radically mismatched poses, hence QC.

## Safe deployment and billing

Full-video continuity v2 uses a NEW immutable namespace:
`nicole_full_480p_continuity_v2_20261115`. Prior paid `v1` requests and
private results remain completely unchanged. Previous v1 cost authorization
`nicole_full_480p_v1_20261115` **does not** enable v2. The existing successful
first 3s identity canary can still be reused if its current source and Nicole
reference are verified to match.

A repeat 13.9-second clip would require 4 new Wan 3.0 generations,
with an estimated $1.10 at the reference-to-video 480p listing, **not** a
provider guarantee. No charge was authorized for this code correction.

Default worker settings remain:
`WORKER_MODE=preflight_only`, `FULL_VIDEO_ONE_SHOT=false`,
`ENABLE_PAID_GENERATION=false`, `ENABLE_PAID_VOICE_GENERATION=false`.

No account API keys, public reference image URLs, or Nicole production
configurations are changed. Source archive, first canary, and completed v1
output are all retained. The isolated staging Telegram command `/fullplan`
provides a no-charge estimate. A new explicit user-approved v2 spending cap,
exact matching `FULL_VIDEO_APPROVAL_ID`, and worker opt-in would be needed for
a paid real-world v2 run.

## Test evidence

- No-payment continuity tests check the actual previous-generated output is
  used, missing prior output blocks, and durable frames survive a restart.
- FFmpeg 2s color-transition test verifies the previous last frame is shown
  at the start of the next section without changing its runtime.
- A full simulated 5-segment 13.9s 480x854 MP4 merge confirms original audio
  and expected duration, without calling WaveSpeed.
- All staging regression tests run in the Render Docker build.
