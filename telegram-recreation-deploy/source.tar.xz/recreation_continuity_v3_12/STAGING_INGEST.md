# Isolated staging: non-paid source archive smoke test

This version adds a single-shot `/archive` action available only to an allowlisted private Telegram user. It executes `python -m recreation.ingest_once` in a separate subprocess on the existing **staging** Render web service; it is not a paid-generation worker and not a production-ready always-on service.

The archiver claims a DRAFT/UPLOAD job atomically using a lease, retrieves the Telegram MP4 using the separate staging bot, uploads it to the existing private Supabase S3-compatible bucket at `recreation/<job_id>/original.mp4`, and only then checkpoints `original_key` and `stage=UPLOAD_REFERENCE` while returning the job to DRAFT. `/status` displays whether the source is permanently saved. The original Telegram file reference remains for retry if the archiver fails or its process is interrupted. Lease timeouts permit recovery without any paid provider request.

A one-time boot run can be enabled with `STAGING_INGEST_ON_BOOT=true`, then disabled after confirmation. The `/archive` command can also start the same single-shot subprocess on demand.

`ENABLE_PAID_GENERATION=false` hard-blocks `/generate` in the webhook. No code in this archiver calls Wan 3.0, Gemini, Grok, or ElevenLabs. No additional billable Render service is provisioned.

**Limitations:** Render's free web service may spin down or restart, so this is a smoke-test tool, not a 24/7 worker. Source video downloads from Telegram's cloud Bot API are limited to about 20 MB. A dedicated background worker and (for large videos) local Bot API server are needed for production. Deploy those only after explicitly approving their compute costs and separately configuring their credentials.

Run offline tests: `PYTHONPATH=. pytest -q`. Deployment Dockerfile runs tests before startup.
