# Wan 3.0 one-shot canary — pending credential and budget checks

This deployment is DISABLED by default. It never changes Nicole production, n8n,
or full-video generation. One 3-second source reference is trimmed from the first
archived FFmpeg preflight segment and used to request one 3-second 480p vertical
video from `alibaba/wan-3.0/reference-to-video`. The original draft remains DRAFT.
No text-to-speech or WaveSpeed LLM is requested.

Expected maximum price from WaveSpeed's published formula: 0.05 USD times
(ceil(reference duration) + 3 output seconds), and the application rejects
requests with an estimate above 0.40 USD. THIS IS AN ESTIMATE, not an account
spending limit guaranteed by WaveSpeed. No automatic retries of a paid POST.

The test uses the original video as Video 1. It checks provider connectivity,
archive and durable prediction polling, not Nicole identity fidelity. There is
no automatic identity swapping without the separately configured Nicole image.

To activate, only in the dedicated Recreation Studio worker set:
  WORKER_MODE=canary_once
  WAN_CANARY_ONE_SHOT=true
  WAN_CANARY_MAX_USD=0.40
  WAN_CANARY_SOURCE_JOB_ID=<owner-approved archived staging job UUID>
  ENABLE_PAID_GENERATION=true
  ENABLE_PAID_VOICE_GENERATION=false
  WAVESPEED_API_KEY=<value stored in Render Secrets, never chat or GitHub>

The worker immediately exits on missing credentials, bad budget, unsupported
source media, invalid owner, missing archived video, or unknown provider
submission state; it must not enter normal paid_pipeline. The step reservation
is named `wan_canary_480p_20261115_001`, permitting at most one paid POST for
the existing source job even after a restart. Polls use the saved provider ID;
completed output is placed into private Supabase storage. If a response is
ambiguous, reconcile manually on WaveSpeed before any new paid request.

After observing a completed or uncertain result, restore:
  WORKER_MODE=preflight_only
  WAN_CANARY_ONE_SHOT=false
  ENABLE_PAID_GENERATION=false

The normal bot web service keeps paid generation disabled throughout.

## Identity fidelity correction — November 15, 2026

Previous connectivity canary was NOT a character replacement test: it supplied
only a source video and instructed Wan to keep the original subject. That first
test is retained as a provider-transport success but rejected for identity.

The staging bot now supports `/identity` on a Nicole photo (as a caption or as
a reply to a photo). The photo is downloaded securely, validated, re-encoded
as a JPEG and stored in the private recreation S3 bucket. The job checkpoint
contains the private object key, and `/status` reports `Nicole identity: ready`.

The corrected one-shot uses a NEW reservation key
`wan_nicole_identity_canary_480p_20261115_002`; it requires a stored Nicole
image, maps Image 1 to Nicole appearance, and maps Video 1 only to motion and
camera guidance. Wan model requests must include reference_images as well as
reference_videos, so source-only paid submissions fail before billing.

Paid generation remains disabled. The original WaveSpeed key stays in the
isolated staging worker; the bot web service is never enabled for paid calls.
The next identity canary requires separate credit authorization and positive
verification of a saved Nicole reference. No previous provider request may
be submitted again.
